export const measurementId = "G-1WSMD45Q9D";
export const appVersion = "13.15.9";
export const analyticsAvailable = true;
export const debugMode = new URLSearchParams(window.location.search).get("analytics_debug") === "1";

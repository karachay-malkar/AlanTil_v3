import { msg } from "../../shared/i18n/index.js?v=13.9.0";
import { getWords } from "../../shared/data/word-repository.js?v=13.13";
import { wordFavorites } from "../../shared/state/word-favorites.js?v=13.9.0";
import { finalizeMatchSession } from "./engine.js?v=13.13";
import { clearMatchSession, matchState } from "./state.js?v=13.9.0";
import { renderMatchGame, renderMatchMenu, renderMatchResult } from "./view.js?v=13.13";

let controller = null;

export async function mount(context, params = {}) {
  context.ensureStyle("/src/features/test/test.css", "test-feature-style");
  context.ensureStyle("/src/features/match/match.css", "match-feature-style");
  controller = new AbortController();
  wordFavorites.reload();
  const words = await getWords();
  const screen = params.screen || "menu";

  if (screen === "game" && (!matchState.session.inProgress || !matchState.total)) {
    await context.router.replace("match.menu", {}, { force: true });
    return;
  }
  if (screen === "results" && !matchState.session.completed) {
    await context.router.replace("match.menu", {}, { force: true });
    return;
  }

  matchState.currentScreen = screen;
  const titles = { menu: msg("match.sopostav_slova"), game: msg("match.sopostav_slova"), results: msg("match.rezultat_igry") };
  context.shell.setHeaderContent?.({ title: titles[screen] || msg("match.sopostav_slova"), logo: true, brand: false });
  if (screen === "menu") renderMatchMenu(context, words, controller.signal);
  else if (screen === "game") renderMatchGame(context, words, controller.signal);
  else if (screen === "results") renderMatchResult(context, words, controller.signal);
  else context.router.replace("match.menu", {}, { force: true });
}

export function onLeave(reason = "route_change") {
  if (matchState.currentScreen !== "game") return;
  const tracker = matchState.session.tracker;
  if (tracker?.getStatus() === "active") {
    tracker.abandon(reason, {
      items_total: matchState.total,
      items_completed: matchState.solvedCount,
      pairs_total: matchState.total,
      pairs_completed: matchState.solvedCount,
      progress_percent: Math.round((matchState.solvedCount / Math.max(1, matchState.total)) * 100),
      errors_count: matchState.errorsCount,
    });
  }
  if (matchState.session.inProgress) finalizeMatchSession("interrupted", reason);
}

export function unmount() {
  controller?.abort();
  controller = null;
  if (matchState.currentScreen === "game" && matchState.session.inProgress) clearMatchSession();
}

export function canLeave() {
  return !(matchState.currentScreen === "game" && matchState.session.inProgress && !matchState.session.completed);
}
